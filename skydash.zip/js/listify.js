  (function($) {
    'use strict';
    var options = {
      valueNames: ['name', 'born']
    };

    var userList = new List('users', options);
  })(jQuery);